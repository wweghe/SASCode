

# 2018.06.08
  * adding a changelog file
  * adding a forced yum re-install, which has helped in the past
  * pushing an old commit to fix an issue


# before that
  * added support for version 6 of RHEL and CENTOS
