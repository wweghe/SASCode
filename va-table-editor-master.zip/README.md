# SAS© Visual Analytics Table Editor Release Notes

## VATableEditor - v5.x

##### **João Oliveira – joao.oliveira@sas.com**

#### **SAS South Western Europe – Customer Advisory**

------
### **What's new in version 5.0**

- **Multi-User : User Concurrence on Save** 
  - VATableEditor will check if table has been modified and if those modifications were made by another VATableEditor User or not. In case that was another VATableEditor User, those changes are assessed to find if there's any impact on the changes about to be saved.

- **Security**: 
  - Align/sync with Viya Group/User Table Authorisations
  - Implement own authorisation schema per table. This is defined at user group and/or user.
  - The functionalities are then align to the Authorisation profile.

- Improved the Auto-loading (if not loaded) tables used on ‘lookup’ and/or as sources for ‘editorSelect’ from ‘table’
- Redesign of Message Boxes to reflect the overall look
- New functions to give more integration options on calling SAS Services and/or 3rd party webservices.
- Some bug fixing and performance improvements.

### What's new in version 4.9.3

- The HTML file where the App is called and defines the App zone, was modified in way that the action buttons are now aligned with the pagination. The Export Data menu was also optimized. These two changes saves screen area!
- Performance optimization on data update/refresh If changing linked VA filters. 

### What's new in version 4.9

- Defining ***validUsers*** at the ***.meta.ctrl.json*** level to add one additional security level. Thus the groups and/or users defined at this level are merged with the ones defined at report level. So a valid user needs to be either registered on the ***.meta.ctrl.json*** or at report level (on the report control file). This for the simple deployment (without a dedicated report control file) if the user isn't registered on the ***.meta.ctrl.json*** can't use the App.
- Ability to configure and then execute in the background External WebServices (e.g.: SAS JobExec) at the Save moments - in Memory and/or on Disk (persisting changes), this after the saving being made successfully. it's possible to call more than one External Service at each moment, which will be executed on the sequence they were defined on the Control File.
- External Services calls / executions, are logged into the Table Tracker. 
- Saving the App log on the file system on ./Logs upon closing report. The ./Logs folder needs to allow writing / creating files.
- If a cell content has changed based on the formula, that is presented as cell tooltip and if user clicks back on the cell for another edition, what's presented is the used formula an not its result.  

### What's new in version 4.5

- Recovery of unsaved changes in case of closing the report. This is configurable on the HTML, control file, master and/or report control file. The recovery depends on how the browser is configured regarding the persistence of cookies. 
- Column independent Header filtering (not dependent from the cell ***editorSelect*** config), in numeric and string/alphanumeric columns. Is possible to filter by *'=', '>', '>=', '<', '<=', '!='* and *'like'* (only for strings). 
- Ability to freeze columns, either on the left and/or right of the table. 4) Informative messages (at the bottom, underneath the buttons) colouring.  

### What's new in version 4.4

- Introduces column aggregations, those are configurable on the report control file and include the most common aggregation functions like: *sum, count, avg, min, max, mean, median absolute deviation (mad), median, mode, product, std deviation, variance* ... Will be possible to have two aggregations per column (one showed on the top and/or other on the bottom). This will be possible to apply for numeric columns, date, datetime and time.

### What's new in version 4.3.5+

- Tracking Changes Table structure was modified to include the report page information, therefore users using previous versions should run the SAS program **AlterTrackerTable.sas**, installed by the ***VATableEditor.json*** as per documentation, is located in Viya content at **/Public/VATableEditor** and executes the SAS Macro ***%VATableEditor_AlterTableChanges(public, VATableEditor_Changes);*** where the first parameter is the CAS library where the tracking changes table is located, the second parameter is the actual tracking changes table name. Thus, adapt/changes the parameters to reflect your deployment.

- Under [Documentation Supplementals](https://gitlab.sas.com/Joao.Oliveira/va-table-editor/-/tree/master/Documentation_Supplementals) there's a [folder](https://gitlab.sas.com/Joao.Oliveira/va-table-editor/-/tree/master/Documentation_Supplementals/Viya4%20Notes) with documentation on how to create a container and then deploy **VATableEditor** in a Viya 2020.1.x (aka Viya 4) pod.

| Release No.   | Date        | Revision Description  |
| ------------- |-------------| -----|
| Rev. 1 | 20JUN2020 | Initial Work |
| Rev. 2 | 12AUG2020 | Installing the Job Execution and registering it on the parameters |
| Rev. 3 | 11SEP2020 | Additional functionalities, setup and usage. Requires tabulator v4.8+ |
| Rev. 4 | 25SEP2020 | Added ‘Paste from Clipboard’ functionality |
| Rev. 5 | 09OCT2020 | Added the Control File managing visible columns and its validations |
| Rev. 6 | 16OCT2020 | Added the ability to export the App logger as JSON, HTML or CSV |
| Rev. 7 | 23OCT2020 | Added on the Control File a column default value fallback on the validation object |
| Rev. 8 | 05NOV2020 | Added display #Rows and select cell value from a Drop-Down List |
| Rev. 9 | 11NOV2020 | Added Header Filtering mapping the Drop-Down List criteria |
| Rev. 10 | 13NOV2020 | Added controlling ‘validUsers’ also by User Group |
| Rev. 11 | 10DEC2020 | **Version 4.0** – Includes multiple new features:<ul><li>Three ways how Control Files can be read</li><li>Table Validation on (re)Loading</li><li>Default behaviour if no Control File(s)/definitions found</li><li>Tracking All Changes made</li><li>Rearranged Cell Context Menu</li><li>Adding Rows - Defaulted row</li><li>Three Saving modes to handle Save in Memory and on Disk</li></ul>And performance improvements, specially needed on validating an entire table (is made cell per cell) and on receiving data from the Clipboard |
| Rev. 12 | 11JAN2021 | Possibility to associate a formula to a column, which can be used to validate its value.<br>Added the ability of a cell receiving the value, which can be calculated by a formula, from another cell or from a lookup table. **New functions were added:** date, year, month, week, day, time, hours, minutes, seconds, lookup |
| Rev. 13 | 19JAN2021 | The ability to of a cell receiving the value:<ul><li>can now include multiple columns</li><li>if formula, that is also applied on column mass change</li></ul> |
| Rev. 14 | 20FEB2021 | Introducing the ability to use formulas on strings (list and syntax as appendix on this document).<br>Introducing the monitoring/inspecting invalid cells. Invalid Cells tooltip will show the violations (see explicative video) and it’s also possible to export / print as well. |
| Rev. 15 | 08MAR2021 | - On the invalid cells information, a suggested value is presented.<br> - Introducing aliases for the date and time functions, like ‘getTime’<=>‘time’ (see manual); additional functions ‘getReportUserId’, ‘getReportUserName’, ‘getReportUID’, ‘getReportSessionUID’. <br> - Adding on the Context Menu, the ability to call external Services. Those can be called in ‘background’ or ‘foreground’ (new Window) mode. This is set per Data Source, look at this [**issue**](https://gitlab.sas.com/Joao.Oliveira/va-table-editor/-/issues/2) for details (also explained on the manual) on how to configure the control file. |
| Rev. 16 | 26MAR2021 | - Ability to define column aggregations, either to be shown on the top and / or at the bottom. Functions possible to use are the most common statistical functions like, sum, avg, mean, mode, median, ... |
| Rev. 17 | 16APR2021 | - Introduces, 1) recovery of unsaved changes in case of closing the report. 2) Independent Header filtering (not dependent from the cell editorSelect config), in numeric and string/alphanumeric columns. 3) ability to freeze columns, either on the left and/or right of the table. 4) Informative messages colouring (at the bottom, underneath the buttons). |
| Rev. 18 | 22APR2021 | - Defining ***validUsers*** at the ***.meta.ctrl.json*** level to add one additional security level.<br>- Ability to configure and then execute in the background External WebServices (e.g.: SAS JobExec) at the Save moments<br>- External Services calls / executions, are logged into the Table Tracker<br>- Saving the App log on the file system on ./Logs upon closing report.<br>- If a cell content has changed based on the formula, that is presented as cell tooltip and if user clicks back on the cell for another edition, what's presented is the used formula an not its result. |
| [Rev. 19](https://gitlab.sas.com/Joao.Oliveira/va-table-editor/-/blob/master/VATableEditor_TechnicalManual_(19).pdf) | 12MAY2021 | **VERSION 5.0** <br/>- **Multi-User : User Concurrence on Save**: VATableEditor will check if table has been modified and if those modifications were made by another VATableEditor User or not. In case that was another VATableEditor User, those changes are assessed to find if there's any impact on the changes about to be saved. <br/>- **Security**:   Align/sync with Viya Group/User Table Authorisations Implement own authorisation schema per table. This is defined at user group and/or user. The functionalities are then align to the Authorisation profile. <br/>- Improved Auto-loading (if not loaded) tables used on ‘lookup’ and/or as sources for ‘editorSelect’ from ‘table’<br/> - Redesign of Message Boxes to reflect the overall look New functions to give more integration options on calling SAS Services and/or 3rd party webservices. <br/>- Some bug fixing and performance improvements. |

[Technical and User Manual](https://gitlab.sas.com/Joao.Oliveira/va-table-editor/-/blob/master/VATableEditor_TechnicalManual_(19).pdf)